function login()
{
    window.location.href = "5_homePage.html"; //after click go to home page
}
function regis()//register button in register.html
{
    window.location.href = "4_done_regis.html"; //after click go to nextpage.html
}

function createaccount() //create account button in login.html
{
    window.location.href = "3_register.html";// after click go to register page
}

function goback() //go back button in nextpage.html
{
    window.location.href = "2_login.html";// after click go back to login page
}
function search() //go to result page after clic
{
    window.location.href = "7_result.html";
}